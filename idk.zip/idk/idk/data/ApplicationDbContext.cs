﻿namespace idk.data
{
    public class ApplicationDbContext
    {
    }
}
