﻿namespace idk.models
{
    public class Follow
    {
    }
}
