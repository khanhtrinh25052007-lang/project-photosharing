﻿namespace idk.models
{
    public class Comment
    {
    }
}
