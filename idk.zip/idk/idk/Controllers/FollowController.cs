﻿using idk.data;
using idk.models;
using Microsoft.AspNetCore.Mvc;

namespace idk.Controllers
{
    public class FollowController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FollowController(ApplicationDbContext context)
        {
            _context = context;                                                                                         
        }

        // Theo dõi người dùng
        [HttpPost]
        public async Task<IActionResult> FollowUser(
            [FromQuery] int followerId,
            [FromQuery] int followingId)
        {
            if (followerId == followingId)
            {
                return BadRequest("Không thể tự theo dõi chính mình!");
            }

            bool usersExist = await _context.Users
                .AnyAsync(u => u.Id == followerId)
                && await _context.Users
                .AnyAsync(u => u.Id == followingId);

            if (!usersExist)
            {
                return NotFound("Người dùng không tồn tại!");
            }

            bool alreadyFollowed = await _context.Follows
                .AnyAsync(f =>
                    f.FollowerId == followerId &&
                    f.FollowingId == followingId);

            if (alreadyFollowed)
            {
                return BadRequest("Bạn đã theo dõi người này!");
            }

            var follow = new Follow
            {
                FollowerId = followerId,
                FollowingId = followingId,
                CreatedAt = DateTime.Now
            };

            _context.Follows.Add(follow);

            await _context.SaveChangesAsync();

            return Ok("Theo dõi thành công!");
        }

        // Hủy theo dõi
        [HttpDelete]
        public async Task<IActionResult> UnfollowUser(
            [FromQuery] int followerId,
            [FromQuery] int followingId)
        {
            var follow = await _context.Follows
                .FirstOrDefaultAsync(f =>
                    f.FollowerId == followerId &&
                    f.FollowingId == followingId);

            if (follow == null)
            {
                return NotFound("Bạn chưa theo dõi người này!");
            }

            _context.Follows.Remove(follow);

            await _context.SaveChangesAsync();

            return Ok("Đã hủy theo dõi!");
        }

        // Danh sách người mình đang theo dõi
        [HttpGet("following/{userId}")]
        public async Task<IActionResult> GetFollowing(int userId)
        {
            var following = await _context.Follows
                .Where(f => f.FollowerId == userId)
                .ToListAsync();

            return Ok(following);
        }

        // Danh sách người đang theo dõi mình
        [HttpGet("followers/{userId}")]
        public async Task<IActionResult> GetFollowers(int userId)
        {
            var followers = await _context.Follows
                .Where(f => f.FollowingId == userId)
                .ToListAsync();

            return Ok(followers);
        }
    }
}
