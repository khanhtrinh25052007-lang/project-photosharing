﻿using idk.data;
using idk.models;
using Microsoft.AspNetCore.Mvc;

namespace idk.Controllers
{
    public class CommentController : Controller
    {
            private readonly ApplicationDbContext _context;

        public CommentController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Lấy danh sách bình luận của bài viết
        [HttpGet("post/{postId}")]
        public async Task<IActionResult> GetComments(int postId)
        {
            var comments = await _context.Comments
                .Where(c => c.PostId == postId)
                .OrderByDescending(c => c.CreatedAt)
                .ToListAsync();

            return Ok(comments);
        }

        // Thêm bình luận
        [HttpPost]
        public async Task<IActionResult> AddComment(Comment comment)
        {
            if (string.IsNullOrWhiteSpace(comment.Content))
            {
                return BadRequest("Nội dung bình luận không được để trống!");
            }

            if (comment.Content.Length > 1000)
            {
                return BadRequest("Bình luận không được quá 1000 ký tự!");
            }

            bool userExists = await _context.Users
                .AnyAsync(u => u.Id == comment.UserId);

            bool postExists = await _context.Posts
                .AnyAsync(p => p.Id == comment.PostId);

            if (!userExists || !postExists)
            {
                return NotFound("Không tìm thấy người dùng hoặc bài viết!");
            }

            comment.Id = 0;
            comment.CreatedAt = DateTime.Now;

            _context.Comments.Add(comment);

            await _context.SaveChangesAsync();

            return Ok(comment);
        }

        // Xóa bình luận
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteComment(int id)
        {
            var comment = await _context.Comments.FindAsync(id);

            if (comment == null)
            {
                return NotFound("Không tìm thấy bình luận!");
            }

            _context.Comments.Remove(comment);

            await _context.SaveChangesAsync();

            return Ok("Xóa bình luận thành công!");
        }
    }
}
